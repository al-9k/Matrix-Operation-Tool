import random
def get_quote_of_the_day():
    quotes = [
        "The eigenvalues of a symmetric matrix are always real numbers.",
        'The term "eigenvalue" comes from the German word "eigen," meaning "own" or "characteristic." Eigenvalues represent the characteristic values of a matrix.',
        "The concept of matrix multiplication was independently discovered by Arthur Cayley and James Joseph Sylvester in the mid-19th century.",
        'Linear algebra plays a crucial role in computer graphics, where matrices are used to represent transformations and projections.',
        'The Cayley-Hamilton Theorem states that every square matrix satisfies its own characteristic equation.',
        'A matrix is said to be positive definite if all its eigenvalues are positive.',
        'Matrices are used in Markov chains to model stochastic processes, such as the transition of a system between different states.',
        'Linear algebra is fundamental to quantum mechanics, where vectors and matrices represent quantum states and operations.',
        'The transpose of a product of matrices is equal to the product of their transposes taken in reverse order.',
        'The Frobenius norm of a matrix is a way of measuring the "size" of a matrix and is defined as the square root of the sum of the squares of its elements.',
        'Gaussian elimination, a method used to solve systems of linear equations, is named after Carl Friedrich Gauss, who made significant contributions to linear algebra.',
        'The determinant of a matrix can be calculated using the cofactor expansion method, which involves breaking down the matrix into smaller submatrices.',
        "Pascal's Triangle, known for its appearance in combinatorics, has connections to binomial coefficients used in expansions of powers of binomials.",
        'The concept of vector spaces and linear transformations forms the basis of abstract algebra and functional analysis.',
        'In linear algebra, a system of linear equations can be represented using matrices and solved using methods like matrix inversion or Gaussian elimination.',
        'The concept of a null space (kernel) and column space (image) of a matrix is essential in understanding its properties and applications.',
        'Linear algebra is extensively used in machine learning algorithms, such as principal component analysis (PCA) and linear regression.',
        'The Jordan normal form is a canonical form for matrices, useful in understanding the behavior of linear transformations.',
        'The Hadamard product (element-wise multiplication) of two matrices results in a matrix where each element is the product of the corresponding elements in the original matrices.',
        'The Kronecker product is a way of combining two matrices to form a larger block matrix.',
        'Matrices play a central role in solving systems of ordinary differential equations, particularly in systems with multiple variables.',
        'The study of linear algebra has deep connections to geometry, where vectors and matrices are used to represent geometric objects and transformations.',
        'The concept of orthogonality is crucial in linear algebra, with orthogonal matrices preserving lengths and angles in transformations.',
        "The zero matrix doesn't change any matrix when added to it.",
        'The determinant of a 2x2 matrix [a, b]/[c, d] is ad - bc.',
        'GUI -- abbreviation for Generated User Interface -- is pronounced "gooey".'
    ]

    return random.choice(quotes)

def print_ascii_art():
    ascii_art = """
  ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⣶⣶⡆⠀⠀⠀⠀⠀⠀⠀⢠⣦⢤⣂⠀⠀⠀⠀⠀⠀⠀⠀⣶⡶⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠙⠛⠛⠛⠻⠟⠿⠿⠿⢛⣟⣻⣛⣛⠛⡟⠛⠛⠛⠛⡛⠛⠻⠿⠟⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠈⠹⢿⣿⣽⣶⢄⠀⠀⠀⠀⠀⢀⣶⣦⣆⣀⣀⣀⣀⣀⣀⣀⣀⣀⣠⣤⡄⠀⠀⠀⠀⠀⢀⣶⣾⢶⣶⣶⣿⣿⣿⠻⠟⣿⣿⠀⠀⠀⢰⣶⣶⣶⣶⣖⣦⠀⠀⠀ ⣶⣶⣶⣶⣶⣶⡶⠿⠾⠿⣿⣿⣿⣷⣶⣶⠆⠐⣴⢶⣶⣶⣶⢦
⠀⠀⠀⣿⣿⣿⣿⣧⠀⠀⠀⢠⣶⣿⣿⣯⠏⠉⠉⠉⠉⠉⢉⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠘⣿⠟⠁⠀⢸⣿⣿⡏⠀⠀⠘⠟⠀⠀⠀⢻⣿⠛⠈⠻⣿⣿⠀⠀⠀⠀⠀⠀⣿⣿⣿⠃⠀⠀⠀⠀⠈⠊⢻⣿⣿⣗⣄⣤⣾⡿⠟⠁⠀⠀
⡄⠀⢰⣿⣿⣟⣿⣷⡷⡀⣴⣿⣷⣿⣿⡏⠀⠀⠀⠀⠀⢠⣾⣿⣛  ⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀ ⢸⣿⣿⣇⣀⣀⣀⣀⣀⣀⣀⣿⣿⣶⣶⣾⣿⣿⠀⠀⠀⠀⠀⠀⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⠊⠀⠀⠀⠀⠀
⠂⠀⢸⣿⣿⠻⠘⢿⣿⣿⣿⡟⠁⢸⣿⡷⠀⠀⠀⠀⣰⣿⣿⠟⠛⠛⠟⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠛⠛⠛⠛⠋⠙⠋⢻⣿⢿⠟⣿⣷⣷⣄⠀⠀⠀⠀⠀⣿⣿⣿⠀⠀⠀⠀⠀⠀⣠⣾⣿⣟⢿⣿⣿⣧⠀⠀⠀⠀⠀
⠀⠀⢸⣿⣿⠀⠀⠈⢻⣿⠟⠀⣴⣾⣿⡷⠀⠀⢠⣰⣿⣿⣧⠀⠀⠀⢠⣿⣿⣿⣶⣦⣤⣤⣤⣤⣤⣤⣾⣿⣿⠿⠵⠆⠀⠀⠀⠀⠀⢺⣿⣿⣤⠈⠚⢿⣷⣷⣦⣄⣤⣴⣿⣿⣿⣤⡄⠀⢀⣠⣾⣿⣿⠋⠉⠂⠹⣿⣿⣿⣦⣀⠀⠀
⠐⠿⠿⠿⠟⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠀⠀⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠁⠘⠛⠛⠟⠛⠻⠂⠀⠀⠛⠛⠻⠙⠛⠻⠝⠐
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⣤⡶⠓⣶⡀⠀⢰⠒⢲⠀⠀⣾⡗⠶⢶⠀⠀⡶⠲⢦⠀⢀⣀⣀⣀⣤⠀⠀⢰⠦⢴⡖⠒⡆⢒⣶⠊⠀⣤⡶⠛⣶⡄⠀⣤⣤⡀⢰⡖⠒⢒⣀⣀⣐⣒⠒⠒⠒⠒⠛⠛⣿⡏⠉ ⠀⣠⡶⠟⢲⡄⠀⢀⣤⠶⠓⣶⡀⢀⢀⣶⠂⠀
⢸⣿⠀⠀⢸⡇⠀⢸⠦⠾⠃⠀⣿⡧⣤⡄⠀⠀⡿⣤⡾⠀⠀⠀⣰⠟⣿⡧⠀⠀⠀⣿⣿⠀⠀⢸⣿⠆⢠⣿⠀⠀⢸⡇⠀⣽⣿⣿⣜⠇⠀⠀⠀⠠⠤⠤⠤⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⣿⠁⠀⠈⡇⠀⢸⣿⠀⠀⢸⡇⠀⠐⣿⣧⠀
⠘⣿⣄⠤⠞⠉⠉⢿⣄⠀⣀⣀⣿⣇⣀⣀⠉⠉⣧⡈⢿⣦⣀⣰⠏⠉⢙⣷⣄⣀⣀⣿⣯⡉⣉⣸⣿⣄⠐⣿⣄⡤⠞⣉⣉⣽⣇⠈⠿⡏⠉⣉⣀⣀⡀⠀⠉⢉⣀⣀⠉⠉⣿⣯⠉⠉⢀⣿⣦⡤⠾⠋⠉⠙⣿⣤⠤⠟⢉⣉⣁⣿⣧⣤⣦
    """
    print(ascii_art)


def display_credits():
    print("========================================================================================================================================================")
    print("  Matrix Operation Tool v0.7")
    print("  GitHub: @al_9k")
    print("  Date: 2023-11-16")
    print("--------------------------------")
    print("")
    print("  Fun Fact:")
    print(get_quote_of_the_day())
    print("")
    print("========================================================================================================================================================")
    print("")

# Call the function to print ASCII art
