# matrix_operations.py

def matrix_addition(matrix1, matrix2):
    
    # checks if matrices have the same dimensions
    if len(matrix1) != len(matrix2) or len(matrix1[0]) != len(matrix2[0]):
        raise ValueError("\nMatrix addition requires matrices of the same dimensions.\n--------------------------------")
    
    # prints the original matrices
    print("\nMatrix 1:")
    for row in matrix1:
        print(row)

    print("\nMatrix 2:")
    for row in matrix2:
        print(row)

    result = [[entry1 + entry2 for entry1, entry2 in zip(row1, row2)] for row1, row2 in zip(matrix1, matrix2)]

    # prints the result matrix
    print("\nResult:")
    for row in result:
        print(row)
    print("--------------------------------")

    return result

################################################

def matrix_multiplication(matrix1, matrix2):
    
    # checks if matrices have compatible dimensions for multiplication
    if len(matrix1[0]) != len(matrix2):
        raise ValueError("Matrix multiplication not possible. Number of columns in the first matrix must be equal to the number of rows in the second matrix.\n--------------------------------")

    # prints the original matrices
    print("\nMatrix 1:")
    for row in matrix1:
        print(row)

    print("\nMatrix 2:")
    for row in matrix2:
        print(row)

    # performs multiplication of matrices
    result = [[sum(a * b for a, b in zip(row1, col2)) for col2 in zip(*matrix2)] for row1 in matrix1]

    # prints the result matrix
    print("\nResult:")
    for row in result:
        print(row)
    print("--------------------------------")
    return result

################################################

def reduce_matrix(matrix):
    
    # prints the original matrix
    print("\nOriginal Matrix:")
    for row in matrix:
        print(row)

    # make a copy of the matrix to avoid modifying the original
    reduced_matrix = [row[:] for row in matrix]

    rows, columns = len(reduced_matrix), len(reduced_matrix[0])
    pivot_row, pivot_col = 0, 0

    # perform Gaussian elimination until REF is reached
    while pivot_row < rows and pivot_col < columns:

        # finds the pivot element in the current column
        pivot = max(range(pivot_row, rows), key=lambda r: abs(reduced_matrix[r][pivot_col]))

        # switches row with the row of the pivot element
        reduced_matrix[pivot], reduced_matrix[pivot_row] = reduced_matrix[pivot_row], reduced_matrix[pivot]

        # makes the pivot element 1
        pivot_element = reduced_matrix[pivot_row][pivot_col]
        if pivot_element != 0:
            reduced_matrix[pivot_row] = [entry / pivot_element for entry in reduced_matrix[pivot_row]]

        # eliminates other entries in the current column
        for i in range(rows):
            if i != pivot_row:
                factor = reduced_matrix[i][pivot_col]
                reduced_matrix[i] = [entry_i - factor * entry_pivot for entry_i, entry_pivot in zip(reduced_matrix[i], reduced_matrix[pivot_row])]

        pivot_row += 1
        pivot_col += 1

    # prints the matrix reduced to REF
    print("\nReduced to REF:")
    for row in reduced_matrix:
        print(row)

    # checks if RREF is possible
    try:
        # test for RREF
        for i in range(min(rows, columns)):
            if reduced_matrix[i][i] != 1:
                raise ValueError("Cannot continue to RREF. Leading entry in each row must be 1.")
            for j in range(i + 1, rows):
                factor = reduced_matrix[j][i]
                reduced_matrix[j] = [entry_j - factor * entry_i for entry_i, entry_j in zip(reduced_matrix[i], reduced_matrix[j])]
    except ValueError:
        print("\nRREF not possible. Matrix remains in REF form:")
        for row in reduced_matrix:
            print(row)
        print("--------------------------------")
        return reduced_matrix

    # prints the matrix reduced to RREF
    print("\nReduced to RREF:")
    for row in reduced_matrix:
        print(row)
    print("--------------------------------")
    return reduced_matrix

################################################

def find_determinant(matrix):

    # checks if the matrix is square
    if len(matrix) != len(matrix[0]):
        print("\nError: Determinant can only be calculated for a square matrix, but the provided matrix is not square.")
        return None  # Or any other value indicating an issue

    # 1x1 matrix is the element itself
    if len(matrix) == 1:
        return matrix[0][0]

    # 2x2 matrix is ad - bc
    if len(matrix) == 2:
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]

    # calculates determinant using expansion by minors
    det = 0
    for i in range(len(matrix)):
        # calculate the minor matrix by excluding the current row and column
        minor_matrix = [row[:i] + row[i+1:] for row in matrix[1:]]
        
        # add the determinant of the minor matrix with appropriate sign
        det += ((-1) ** i) * matrix[0][i] * find_determinant(minor_matrix)

    return det

################################################

def cofactor_matrix(matrix):
    rows, cols = len(matrix), len(matrix[0])

    cofactor_matrix = []

    for i in range(rows):
        cofactor_row = []
        for j in range(cols):
            # calculates the sign factor
            sign = (-1) ** (i + j)

            # calculates the determinant of the matrix formed by removing the current row and column
            minor_matrix = [row[:j] + row[j+1:] for row in (matrix[:i] + matrix[i+1:])]
            determinant = find_determinant(minor_matrix)

            # calculates the cofactor and append to the row
            cofactor_value = sign * determinant
            cofactor_row.append(cofactor_value)

        # appends the row to the cofactor matrix
        cofactor_matrix.append(cofactor_row)

    return cofactor_matrix

################################################

def inverse_matrix(matrix):
    try:
        # calculates the determinant of the original matrix
        det = find_determinant(matrix)

        # checks if the determinant is non-zero (matrix is invertible)
        if det == 0:
            raise ValueError("Matrix is not invertible. Determinant is zero.")

        # calculates the cofactor matrix
        cofactor_matrix_result = cofactor_matrix(matrix)

        # transposes the cofactor matrix to get the adjugate matrix
        adjugate_matrix = [[cofactor_matrix_result[j][i] for j in range(len(cofactor_matrix_result))] for i in range(len(cofactor_matrix_result[0]))]

        # calculates the inverse matrix
        inverse_matrix_result = [[elem / det for elem in row] for row in adjugate_matrix]

        return inverse_matrix_result

    except ValueError as e:
        print(f"\nError: {e}")
        print("--------------------------------")
        return None

