# main.py
from matrix_operations import *
from canvas import *

# defines the main menu options
def display_menu():
    print("1. Matrix Multiplication")
    print("2. Matrix Addition")
    print("3. Matrix Reduction")
    print("4. Find Determinant")
    print("5. Find Cofactor Matrix")
    print("6. Find Inverse Matrix")
    print("7. Exit")


# takes input from user
def get_matrix_input():
    while True:
        try:
            matrix_str = input("Enter the matrix in the format '[a11, a12, ..., a1n]/[a21, a22, ..., a2n]/.../[am1, am2, ..., amn]': ")

            # rows split by /
            rows_str = matrix_str.split('/')
            matrix = []

            for row_str in rows_str:
                row = [float(element.strip()) for element in row_str[1:-1].split(',')]
                
                # checks if the input is a list
                if not isinstance(row, list):
                    raise ValueError("Invalid input. Please enter a valid matrix.")
                
                matrix.append(row)

            # checks if all rows have the same number of elements
            if not all(len(row) == len(matrix[0]) for row in matrix):
                raise ValueError("Invalid input. All rows must have the same number of elements.")

            return matrix

        except (ValueError, IndexError) as e:
            print(f"Invalid input. {e}")
        except Exception as e:
            print(f"An error occurred: {e}")


def main():

    print_ascii_art() # ASCII
    display_credits() # credits

    print("How can M.O.T. help?")

    while True:
        display_menu()
        choice = input("[1-7]")

        if choice == '1':
            matrix1 = get_matrix_input()
            matrix2 = get_matrix_input()

            try:
                result = matrix_multiplication(matrix1, matrix2)
            except ValueError as e:
                print(f"Error: {e}")

        elif choice == '2':
            matrix1 = get_matrix_input()
            matrix2 = get_matrix_input()

            try:
                result = matrix_addition(matrix1, matrix2)
            except ValueError as e:
                print(f"Error: {e}")

        elif choice == '3':
            matrix = get_matrix_input()
            reduce_matrix(matrix)

        elif choice == '4':
            matrix = get_matrix_input()
            
            print("\nOriginal Matrix:")
            for row in matrix:
                print(row)
            
            determinant_result = find_determinant(matrix)
            print(f"\nDeterminant: {determinant_result}\n--------------------------------")

        elif choice == '5':
            matrix = get_matrix_input()

            print("\nOriginal Matrix:")
            for row in matrix:
                print(row)

            cofactor_matrix_result = cofactor_matrix(matrix)
            
            print("\nCofactor Matrix:")
            for row in cofactor_matrix_result:
                print(row)
            print("--------------------------------")

        elif choice == '6':
            matrix = get_matrix_input()

            print("\nOriginal Matrix:")
            for row in matrix:
                print(row)

            inverse_matrix_result = inverse_matrix(matrix)
            
            if inverse_matrix_result is not None:
                print("\nInverse Matrix:")
                for row in inverse_matrix_result:
                    print(row)
                print("--------------------------------")

        elif choice == '7':
            print("Exiting... Goodnight!")
            break

        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
